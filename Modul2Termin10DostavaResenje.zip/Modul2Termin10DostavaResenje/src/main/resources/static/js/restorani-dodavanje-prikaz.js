/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let naziv = document.querySelector("input[name=naziv]");
	let kategorijaIds = document.querySelectorAll("input[name=kategorijaIds]");
	let datumOsnivanja = document.querySelector("input[name=datumOsnivanja]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaNaziv() {
		return naziv.value != ""; // input.value
	}
	function validacijaKategorijaIds() {
		let odabran = false;
		for (let itKategorijaId of kategorijaIds) {
			if (itKategorijaId.checked) { // input.checked (funkcioniše za checkbox i radio)
				odabran = true;
				break;
			}
		}
		return odabran;
	}
	function validacijaDatumOsnivanja() {
		return new Date(datumOsnivanja.value) <= new Date(); // input.value
	}
	function validacija() {
		return validacijaNaziv() && validacijaKategorijaIds() && validacijaDatumOsnivanja();
	}

	// registracija handler-a na događaje promene unosa input-a
	let nazivCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaNaziv()? "": "Naziv ne sme biti prazan!";
	
		button.disabled = !validacija(); // objedinjena validacija
	};
	naziv.onchange = nazivCallback;
	naziv.onblur = nazivCallback;
	naziv.onkeyup = nazivCallback;

	let kategorijaIdsCallback = function(event) {
		// prikaz poruke
		let error = event.target.parentElement.parentElement.lastElementChild; // input -> div -> div -> small
		error.textContent = validacijaKategorijaIds()? "": "Bar jedna kategorija mora biti odabrana!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	for (let itKategorijaId of kategorijaIds) { // registracija handler-a na sve checkbox-e
		itKategorijaId.onchange = kategorijaIdsCallback;
		itKategorijaId.onblur = kategorijaIdsCallback;
		itKategorijaId.onkeyup = kategorijaIdsCallback;
	}

	let datumOsnivanjaCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaDatumOsnivanja()? "": "Datum osnivanja ne sme biti u budućnosti!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	datumOsnivanja.onchange = datumOsnivanjaCallback;
	datumOsnivanja.onblur = datumOsnivanjaCallback;
	datumOsnivanja.onkeyup = datumOsnivanjaCallback;

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let naziv = document.querySelector("input[name=naziv]");
	let cena = document.querySelector("input[name=cena]");
	let restoranId = document.querySelector("select[name=restoranId]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaNaziv() {
		return naziv.value != ""; // input.value
	}
	function validacijaCena() {
		return Number(cena.value) > 0; // input.value
	}
	function validacijaRestoranId() {
		return restoranId.value > 0; // input.value
	}
	function validacija() {
		return validacijaNaziv() && validacijaCena() && validacijaRestoranId();
	}

	// registracija handler-a na događaje promene unosa input-a
	let nazivCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaNaziv()? "": "Naziv ne sme biti prazan!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	naziv.onchange = nazivCallback;
	naziv.onblur = nazivCallback;
	naziv.onkeyup = nazivCallback;

	let cenaKarteCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaCena()? "": "Cena mora biti pozitivan broj!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	cena.onchange = cenaKarteCallback;
	cena.onblur = cenaKarteCallback;
	cena.onkeyup = cenaKarteCallback;

	let restoranIdCallback = function(event) {
		console.log("");
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaRestoranId()? "": "Restoran mora biti odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	restoranId.onchange = restoranIdCallback;
	restoranId.onblur = restoranIdCallback;
	restoranId.onkeyup = restoranIdCallback;

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let prikaz = document.querySelectorAll("form").length > 1;

	let korisnickoIme = document.querySelector("input[name=korisnickoIme]");
	let lozinka = document.querySelector("input[name=lozinka]");
	let ponovljenaLozinka = document.querySelector("input[name=ponovljenaLozinka]");
	let eMail = document.querySelector("input[name=eMail]");
	let pol = document.querySelectorAll("input[name=pol]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaKorisnickoIme() {
		return korisnickoIme.value.match("^[a-zA-Z0-9]+$") != null; // input.value
	}
	function validacijaLozinka() {
		return lozinka.value != ""; // input.value
	}
	function validacijaPonovljenaLozinka() {
		return lozinka.value == ponovljenaLozinka.value; // input.value
	}
	function validacijaEMail() {
		return eMail.value.match("^[a-zA-Z0-9]+@[a-zA-Z0-9]+.com$") != null; // input.value
	}
	function validacijaPol() {
		let odabran = false;
		for (let itPol of pol) {
			if (itPol.checked) { // input.checked (funkcioniše za checkbox i radio)
				odabran = true;
				break;
			}
		}
		return odabran;
	}
	function validacija() { // ukoliko je učitana stranica za prikaz, korisničko ime i lozinka se ne proveravaju
		return (prikaz || validacijaKorisnickoIme()) && (prikaz || validacijaLozinka()) && validacijaPonovljenaLozinka() && validacijaEMail() && validacijaPol();
	}

	// registracija handler-a na događaje promene unosa input-a
	let korisnickoImeCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = (prikaz || validacijaKorisnickoIme())? "": "Korisničko ime ne sme biti prazno i sme da sadrži samo slova i cifre!";
	
		button.disabled = !validacija();
	};
	korisnickoIme.onchange = korisnickoImeCallback;
	korisnickoIme.onblur = korisnickoImeCallback;
	korisnickoIme.onkeyup = korisnickoImeCallback;

	let lozinkaPonovljenaLozinkaCallback = function() { // zajednička provera jer su polja povezana
		// prikaz poruke
		let error;

		// lozinka
		error = lozinka.nextElementSibling; // input -> small
		error.textContent = (prikaz || validacijaLozinka())? "": "Lozinka ne sme biti prazna!";
		// ponovljena lozinka
		error = ponovljenaLozinka.nextElementSibling; // input -> small
		error.textContent = validacijaPonovljenaLozinka()? "": "Lozinke se ne podudaraju!";
	
		button.disabled = !validacija();
	};
	lozinka.onchange = lozinkaPonovljenaLozinkaCallback;
	lozinka.onblur = lozinkaPonovljenaLozinkaCallback;
	lozinka.onkeyup = lozinkaPonovljenaLozinkaCallback;
	ponovljenaLozinka.onchange = lozinkaPonovljenaLozinkaCallback;
	ponovljenaLozinka.onblur = lozinkaPonovljenaLozinkaCallback;
	ponovljenaLozinka.onkeyup = lozinkaPonovljenaLozinkaCallback;

	let eMailCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaEMail()? "": "E-mail nije u odgovarajućem obliku!";
	
		button.disabled = !validacija(); // objedinjena validacija
	};
	eMail.onchange = eMailCallback;
	eMail.onblur = eMailCallback;
	eMail.onkeyup = eMailCallback;

	let polCallback = function(event) {
		// prikaz poruke
		let error = event.target.parentElement.parentElement.lastElementChild; // input -> div -> div -> small
		error.textContent = validacijaPol()? "": "Pol nije odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	for (let itPol of pol) {
		itPol.onchange = polCallback;
		itPol.onblur = polCallback;
		itPol.onkeyup = polCallback;
	}

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


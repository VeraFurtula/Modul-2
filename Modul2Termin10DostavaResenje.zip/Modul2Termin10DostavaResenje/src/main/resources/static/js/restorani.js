/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let tbody = document.querySelector("tbody");

	let buttonsSortNaziv = document.querySelectorAll("button.sort-naziv");
	let buttonsSortDatumOsnivanja = document.querySelectorAll("button.sort-datumOsnivanja");

	// funkcija za sortiranje tabele po prosleđenom komparatoru
	function sortTBody(comp) {
		// pravljenje niza od kolekcije HTML elemenata
		let redovi = Array.of(...tbody.children); // ... unpack operator
		redovi.sort(comp);

		// pražnjenje tabele
		while (tbody.children.length > 0) {
			tbody.children[0].remove();
		}
		// popunjavanje tabele u sortiranom redosledu redova
		for (let it in redovi) {
			let red = redovi[it];
			red.children[0].textContent = Number(it) + 1; // ažuriranje rednog broja
			tbody.append(red);
		}
	}

	function parseDate(string) {
		let date = string.split(".");
		return new Date(`${date[2]}-${date[1]}-${date[0]}`);
	}

	// funkcije za sortiranje po koloni
	function sortNaziv(smer) {
		sortTBody(function(red1, red2) {
			let naziv1 = red1.children[1].children[0].textContent; // tr -> td -> a.textContent
			let naziv2 = red2.children[1].children[0].textContent;
			return smer*(naziv1.localeCompare(naziv2));
		});
	}
	function sortDatumOsnivanja(smer) {
		sortTBody(function(red1, red2) {
			let datumOsnivanja1 = parseDate(red1.children[3].textContent); // tr -> a.textContent
			let datumOsnivanja2 = parseDate(red2.children[3].textContent);
			if (datumOsnivanja1 > datumOsnivanja2) {
				return smer;
			} else if (datumOsnivanja2 > datumOsnivanja1) {
				return -smer;
			}
			return 0;
		});
	}

	// registracija događaja
	buttonsSortNaziv[0].onclick = function(event) { // event parametar je opisnik događaja
		sortNaziv(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortNaziv[1].onclick = function(event) { // event parametar je opisnik događaja
		sortNaziv(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortDatumOsnivanja[0].onclick = function(event) { // event parametar je opisnik događaja
		sortDatumOsnivanja(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortDatumOsnivanja[1].onclick = function(event) { // event parametar je opisnik događaja
		sortDatumOsnivanja(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
}
/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let naziv = document.querySelector("input[name=naziv]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaNaziv() {
		return naziv.value != ""; // input.value
	}
	function validacija() {
		return validacijaNaziv();
	}

	// registracija handler-a na događaje promene unosa input-a
	let nazivCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaNaziv()? "": "Naziv ne sme biti prazan!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	naziv.onchange = nazivCallback;
	naziv.onblur = nazivCallback;
	naziv.onkeyup = nazivCallback;

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


package com.ftninformatika.jwd.modul2.termin10.dostava.model.session;

import java.util.Collection;

public interface ArtikliIstorija {

	public void addPosecen(long id);
	public void deletePosecen(long id);
	public Collection<Long> getAllPoseceni();

}

package com.ftninformatika.modul2.restoran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestoranApplicationTests {

	@Test
	void contextLoads() {
	}

}

class Bioskop {
    static zanrovi = new Map();
    static filmovi = new Map();
    static projekcije = new Map();
    static korisnici = new Map();

	static maxZanrId;
	static maxFilmId;
	static maxProjekcijaId;

    static inicijalizuj() {
		// kreiranje žanrova
		this.zanrovi.set(1, new Zanr(1, "naučna fantastika"));
		this.zanrovi.set(2, new Zanr(2, "akcija"));
		this.zanrovi.set(3, new Zanr(3, "komedija"));
		this.zanrovi.set(4, new Zanr(4, "horor"));
		this.zanrovi.set(5, new Zanr(5, "avantura"));

		// kreiranje filmova
		this.filmovi.set(1, new Film(1, "Avengers: Endgame", 182));
		this.filmovi.set(2, new Film(2, "Life", 110));
		this.filmovi.set(3, new Film(3, "It: Chapter 2", 170));
		this.filmovi.set(4, new Film(4, "Pirates of the Caribbean: Dead Men Tell No Tales", 153));

		// povezivanje filmova i žanrova
		this.filmovi.get(1).addZanr(this.zanrovi.get(1));
		this.filmovi.get(2).addZanr(this.zanrovi.get(1));
		this.filmovi.get(1).addZanr(this.zanrovi.get(2));
		this.filmovi.get(4).addZanr(this.zanrovi.get(2));
		this.filmovi.get(4).addZanr(this.zanrovi.get(3));
		this.filmovi.get(2).addZanr(this.zanrovi.get(4));
		this.filmovi.get(3).addZanr(this.zanrovi.get(4));
		this.filmovi.get(1).addZanr(this.zanrovi.get(5));
		this.filmovi.get(4).addZanr(this.zanrovi.get(5));

		// kreiranje i karata i povezivanje karata i filmova
		this.projekcije.set(1, new Projekcija(1, new Date("2020-06-22T20:00:00"), this.filmovi.get(1), 1, "2D", 380.00));
		this.projekcije.set(2, new Projekcija(2, new Date("2020-06-22T23:30:00"), this.filmovi.get(3), 1, "2D", 380.00));
		this.projekcije.set(3, new Projekcija(3, new Date("2020-06-22T20:00:00"), this.filmovi.get(1), 2, "3D", 420.00));
		this.projekcije.set(4, new Projekcija(4, new Date("2020-06-22T23:30:00"), this.filmovi.get(2), 2, "3D", 420.00));
		this.projekcije.set(5, new Projekcija(5, new Date("2020-06-22T20:00:00"), this.filmovi.get(3), 3, "4D", 580.00));
		this.projekcije.set(6, new Projekcija(6, new Date("2020-06-23T20:00:00"), this.filmovi.get(2), 1, "2D", 380.00));
		this.projekcije.set(7, new Projekcija(7, new Date("2020-06-23T22:00:00"), this.filmovi.get(4), 1, "2D", 380.00));
		this.projekcije.set(8, new Projekcija(8, new Date("2020-06-23T20:00:00"), this.filmovi.get(2), 2, "3D", 420.00));
		this.projekcije.set(9, new Projekcija(9, new Date("2020-06-23T22:00:00"), this.filmovi.get(4), 2, "3D", 420.00));
		this.projekcije.set(10, new Projekcija(10, new Date("2020-06-23T20:00:00"), this.filmovi.get(1), 3, "4D", 580.00));

        this.maxZanrId = 5;
        this.maxFilmId = 4;
        this.maxProjekcijaId = 10;

		this.korisnici.set("a", new Korisnik("a", "a", "a@a.com", "muški", true));
		this.korisnici.set("b", new Korisnik("b", "b", "b@b.com", "ženski", false));
		this.korisnici.set("c", new Korisnik("c", "c", "c@c.com", "muški", false));
    }

    static nextZanrId() {
        this.maxZanrId++;
        return this.maxZanrId;
    }

    static nextFilmId() {
        this.maxFilmId++;
        return this.maxFilmId;
    }

    static nextProjekcijaId() {
        this.maxProjekcijaId++;
        return this.maxProjekcijaId;
    }

}

Bioskop.inicijalizuj();

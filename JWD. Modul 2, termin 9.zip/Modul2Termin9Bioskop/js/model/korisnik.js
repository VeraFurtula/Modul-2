class Korisnik {

    constructor(korisnickoIme, lozinka, eMail, pol, administrator) {
        this.korisnickoIme = korisnickoIme;
        this.lozinka = lozinka;
        this.eMail = eMail;
        this.pol = pol;
        this.administrator = administrator;
    }

}
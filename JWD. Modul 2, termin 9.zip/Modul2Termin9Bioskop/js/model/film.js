class Film {

    constructor(id, naziv, trajanje) {
        this.id = id;
        this.naziv = naziv;
        this.trajanje = trajanje;

        this.zanrovi = [];
    }

    addZanr(zanr) {
        if (this.zanrovi.includes(zanr)) {
            return;
        }
        this.zanrovi.push(zanr);
    }

    removeZanr(zanr) {
        let index = this.zanrovi.indexOf(zanr);
        if (index > -1) {
            this.zanrovi.splice(index, 1);
        }
    }

    findNedostajuciZanrovi(zanrovi) {
        let rezultat = [];
        for (let itZanr of zanrovi) {
            if (!this.zanrovi.includes(itZanr)) {
                rezultat.push(itZanr);
            }
        }
        return rezultat;
    }
}
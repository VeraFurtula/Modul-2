class Projekcija {

    constructor(id, datum, film, tip, sala, cenaKarte) {
        this.id = id;
        this.datum = datum;
        this.film = film;
        this.tip = tip;
        this.sala = sala;
        this.cenaKarte = cenaKarte;
    }

}
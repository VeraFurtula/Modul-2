class Zanr {

    constructor(id, naziv) {
        this.id = id;
        this.naziv = naziv;
    }

}
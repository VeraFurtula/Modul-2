class Konzola {

    static ocitajString(poruka) {
        console.log("\n");
        console.log(`${poruka}...`);

        let vrednost = "";
        while (vrednost == null || vrednost == "") {
            vrednost = prompt(`${poruka}:`);
        }
        console.log(`Uneli ste: ${vrednost}`);
        return vrednost;
    }

    static ocitajNumber(poruka) {
        let vrednost = null;
        while (vrednost == null || vrednost == NaN) {
            vrednost = Number(this.ocitajString(poruka));
        }
        return vrednost;
    }

    static ocitajDate(poruka) {
        let vrednost = null;
        while (vrednost == null || !vrednost.valueOf()) {
            let string = this.ocitajString(`${poruka} (dd.MM.yyyy. HH:mm)`);
            let tokens = string.split(" ");
            let date = tokens[0].split(".");
            let time = tokens[1].split(":");
            vrednost = new Date(`${date[2]}-${date[1]}-${date[0]}T${time[0]}:${time[1]}`);
        }
        return vrednost;
    }

    static ocitajBoolean(poruka) {
        let vrednost = null;
        while (vrednost == null) {
            let string = this.ocitajString(`${poruka}? Unesite izbor (d/n):`);
            switch (string) {
                case "d": {
                    vrednost = true;
                    break;
                }
                case "n": {
                    vrednost = false;
                    break;
                }
            }
        }
        return vrednost;
    }

}
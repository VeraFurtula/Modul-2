class ProjekcijaUI { 

    static prikazSvih(projekcije) {
        if (projekcije == undefined) {
            projekcije = Array.from(Bioskop.projekcije.values()).sort(function(projekcija1, projekcija2) {
                return projekcija1.id - projekcija2.id;
            });
        }
        console.log("\n");
        for (let itProjekcija of projekcije) {
            console.log(itProjekcija);
        }
    }

    static pronalazenje(poruka = "Unesite ID", projekcije) {
        this.prikazSvih(projekcije);

        let id = Konzola.ocitajNumber(poruka);

        let projekcija = Bioskop.projekcije.get(id);
        if (projekcija == null) {
            console.log("\n");
            console.log("Projekcija nije pronađena!");
        }
        return projekcija;
    }

    static prikaz() {
        let projekcija = this.pronalazenje();
        if (projekcija == null) {
            return;
        }
        console.log("\n");
        console.log(projekcija);
    }

    static dodavanje() {
        let datum = null;
        while (datum == null || datum < Date.now()) {
            datum = Konzola.ocitajDate("Unesite datum");
        }
        let film = null;
        while (film == null) {
            film = FilmUI.pronalazenje("Unesite ID filma"); // many-to-one
        }
        let tip = null;
        while (tip == null || !(tip == "2D" || tip == "3D" || tip == "4D")) {
            tip = Konzola.ocitajString("Unesite tip");
        }
        let sala = null;
        while (sala == null || !(sala > 0 && sala <= 3)) {
            sala = Konzola.ocitajNumber("Unesite salu");
        }
        let cenaKarte = null;
        while (cenaKarte == null || cenaKarte <= 0) {
            cenaKarte = Konzola.ocitajNumber("Unesite cenu karte");
        }

        let id = Bioskop.nextProjekcijaId();
        let projekcija = new Projekcija(id, datum, film, tip, sala, cenaKarte);
        Bioskop.projekcije.set(id, projekcija);

        console.log("\n");
        console.log("Dodavanje uspešno!");
    }

    static izmena() {
        let projekcija = this.pronalazenje();
        if (projekcija == null) {
            return;
        }

        let datum = null;
        while (datum == null || datum < Date.now()) {
            datum = Konzola.ocitajDate("Unesite datum");
        }
        let film = null;
        while (film == null) {
            film = FilmUI.pronalazenje("Unesite ID filma"); // many-to-one
        }
        let tip = null;
        while (tip == null || !(tip == "2D" || tip == "3D" || tip == "4D")) {
            tip = Konzola.ocitajString("Unesite tip");
        }
        let sala = null;
        while (sala == null || !(sala > 0 && sala <= 3)) {
            sala = Konzola.ocitajNumber("Unesite salu");
        }
        let cenaKarte = null;
        while (cenaKarte == null || cenaKarte <= 0) {
            cenaKarte = Konzola.ocitajNumber("Unesite cenu karte");
        }
        projekcija.datum = datum;
        projekcija.film = film;
        projekcija.tip = tip;
        projekcija.sala = sala;
        projekcija.cena = cenaKarte;

        console.log("\n");
        console.log("Izmena uspešna!");
    }

    static brisanje() {
        let projekcija = this.pronalazenje();
        if (projekcija == null) {
            return;
        }
        Bioskop.projekcije.delete(projekcija.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Projekcije");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");
    
            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
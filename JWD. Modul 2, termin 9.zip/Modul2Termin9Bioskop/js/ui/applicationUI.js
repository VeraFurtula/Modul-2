class ApplicationUI {

    static meni() {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n")
            console.log("Bioskop");
            console.log("-------------");
            console.log("0. Izlaz");
            console.log("1. Žanrovi");
            console.log("2. Filmovi");
            console.log("3. Projekcije");
            console.log("4. Korisnici");
            console.log("-------------");
    
            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    ZanrUI.meni();
                    break;
                }
                case "2": {
                    FilmUI.meni();
                    break;
                }
                case "3": {
                    ProjekcijaUI.meni();
                    break;
                }
                case "4": {
                    KorisnikUI.meni();
                    break;
                }
            }
        }
    }

}

ApplicationUI.meni();
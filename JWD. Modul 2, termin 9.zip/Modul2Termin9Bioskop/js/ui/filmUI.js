class FilmUI { 

    static prikazSvih(filmovi) {
        if (filmovi == undefined) {
            filmovi = Array.from(Bioskop.filmovi.values()).sort(function(film1, film2) {
                return film1.id - film2.id;
            });
        }
        console.log("\n");
        for (let itFilm of filmovi) {
            console.log(itFilm);
        }
    }

    static pronalazenje(poruka = "Unesite ID", filmovi) {
        this.prikazSvih(filmovi);

        let id = Konzola.ocitajNumber(poruka);

        let film = Bioskop.filmovi.get(id);
        if (film == null) {
            console.log("\n");
            console.log("Film nije pronađen!");
        }
        return film;
    }

    static prikaz() {
        let film = this.pronalazenje();
        if (film == null) {
            return;
        }
        console.log("\n");
        console.log(film);
    }

    static dodavanje() {
        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let trajanje = null;
        while (trajanje == null || trajanje < 5) {
            trajanje = Konzola.ocitajNumber("Unesite trajanje");
        }
        let id = Bioskop.nextFilmId();
        let film = new Film(id, naziv, trajanje);
        Bioskop.filmovi.set(id, film);

        console.log("\n");
        console.log("Dodavanje uspešno!");

        // many-to-many
        let nedostajuciZanrovi = film.findNedostajuciZanrovi(Bioskop.zanrovi.values());
        while (nedostajuciZanrovi.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da dodate žanr")) {
			let zanr = ZanrUI.pronalazenje("Unesite ID žanra", nedostajuciZanrovi);
			if (zanr == null) {
				continue;
            }
            film.addZanr(zanr);

            console.log("\n");
            console.log("Žanr je dodat!");	
            
            nedostajuciZanrovi = film.findNedostajuciZanrovi(Bioskop.zanrovi.values())
		}
    }

    static izmena() {
        let film = this.pronalazenje();
        if (film == null) {
            return;
        }

        let naziv = "";
        while (naziv == "") {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let trajanje = null;
        while (trajanje == null || trajanje < 5) {
            trajanje = Konzola.ocitajNumber("Unesite trajanje");
        }
        film.naziv = naziv;
        film.trajanje = trajanje;

        console.log("\n");
        console.log("Izmena uspešna!");

         // many-to-many
        while (film.zanrovi.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da uklonite žanr")) {
			let zanr = ZanrUI.pronalazenje("Unesite ID žanra", film.zanrovi);
			if (zanr == null) {
				continue;
            }
            film.removeZanr(zanr);

            console.log("\n");
            console.log("Žanr je uklonjen!");		
		}
        let nedostajuciZanrovi = film.findNedostajuciZanrovi(Bioskop.zanrovi.values());
        while (nedostajuciZanrovi.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da dodate žanr")) {
			let zanr = ZanrUI.pronalazenje("Unesite ID žanra", nedostajuciZanrovi);
			if (zanr == null) {
				continue;
            }
            film.addZanr(zanr);

            console.log("\n");
            console.log("Žanr je dodat!");	
            
            nedostajuciZanrovi = film.findNedostajuciZanrovi(Bioskop.zanrovi.values())
		}
    }

    static brisanje() {
        let film = this.pronalazenje();
        if (film == null) {
            return;
        }
        for (let itProjekcija of Bioskop.projekcije.values()) {
            if (itProjekcija.film == film) {
                console.log("\n");
                console.log("Film je povezan!");
                return;
            }
        }

        Bioskop.filmovi.delete(film.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Filmovi");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");

            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
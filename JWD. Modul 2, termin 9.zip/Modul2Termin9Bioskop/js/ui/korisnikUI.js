class KorisnikUI { 

    static prikazSvih(korisnici) {
        if (korisnici == undefined) {
            korisnici = Array.from(Bioskop.korisnici.values()).sort(function(korisnik1, korisnik2) {
                return korisnik1.korisnickoIme.localeCompare(korisnik2.korisnickoIme);
            });
        }
        console.log("\n");
        for (let itKorisnik of korisnici) {
            console.log(itKorisnik);
        }
    }

    static pronalazenje(poruka, korisnici) {
        this.prikazSvih(korisnici);

        let korisnickoIme = Konzola.ocitajString(poruka);

        let korisnik = Bioskop.korisnici.get(korisnickoIme);
        if (korisnik == null) {
            console.log("\n");
            console.log("Korisnik nije pronađen!");
        }
        return korisnik;
    }

    static prikaz() {
        let korisnik = this.pronalazenje("Unesite korisničko ime");
        if (korisnik == null) {
            return;
        }
        console.log("\n");
        console.log(korisnik);
    }

    static dodavanje() {
        let korisnickoIme = null;
        while (korisnickoIme == null || Bioskop.korisnici.has(korisnickoIme) || korisnickoIme.match("^[a-zA-Z0-9]+$") == null) {
            korisnickoIme = Konzola.ocitajString("Unesite korisničko ime");
        }
        let lozinka = null;
        while (lozinka == null) {
            lozinka = Konzola.ocitajString("Unesite lozinku");
        }
        let eMail = null;
        while (eMail == null || eMail.match("^[a-zA-Z0-9]+@[a-zA-Z0-9]+.com$") == null) {
            eMail = Konzola.ocitajString("Unesite e-mail");
        }
        let pol = null;
        while (pol == null || !(pol == "muški" || pol == "ženski")) {
            let string = Konzola.ocitajString("Unesite pol (m/z)");
            switch (string) {
                case "m": {
                    pol = "muški";
                    break;
                }
                case "z": {
                    pol = "ženski";
                    break;
                }
            }
        }
        let administrator = null;
        while (administrator == null) {
            administrator = Konzola.ocitajBoolean("Da li je korisnik administrator");
        }

        let korisnik = new Korisnik(korisnickoIme, lozinka, eMail, pol, administrator);
        Bioskop.korisnici.set(korisnickoIme, korisnik);

        console.log("\n");
        console.log("Dodavanje uspešno!");
    }

    static izmena() {
        let korisnik = this.pronalazenje("Unesite korisničko ime");
        if (korisnik == null) {
            return;
        }

        let lozinka = null;
        while (lozinka == null) {
            lozinka = Konzola.ocitajString("Unesite lozinku");
        }
        let eMail = null;
        while (eMail == null || eMail.match("^[a-zA-Z0-9]+@[a-zA-Z0-9]+.com$") == null) {
            eMail = Konzola.ocitajString("Unesite e-mail");
        }
        let pol = null;
        while (pol == null || !(pol == "muški" || pol == "ženski")) {
            let string = Konzola.ocitajString("Unesite pol (m/z)");
            switch (string) {
                case "m": {
                    pol = "muški";
                    break;
                }
                case "z": {
                    pol = "ženski";
                    break;
                }
            }
        }
        let administrator = null;
        while (administrator == null) {
            administrator = Konzola.ocitajBoolean("Da li je korisnik administrator");
        }
        korisnik.lozinka = lozinka;
        korisnik.eMail = eMail;
        korisnik.pol = pol;
        korisnik.administrator = administrator;

        console.log("\n");
        console.log("Izmena uspešna!");
    }

    static brisanje() {
        let korisnik = this.pronalazenje("Unesite korisničko ime");
        if (korisnik == null) {
            return;
        }
        Bioskop.korisnici.delete(korisnik.korisnickoIme);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Korisnici");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");
    
            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
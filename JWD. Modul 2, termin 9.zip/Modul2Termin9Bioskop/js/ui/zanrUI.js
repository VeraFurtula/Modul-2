class ZanrUI { 

    static prikazSvih(zanrovi) {
        if (zanrovi == undefined) {
            zanrovi = Array.from(Bioskop.zanrovi.values()).sort(function(zanr1, zanr2) {
                return zanr1.id - zanr2.id;
            });
        }
        console.log("\n");
        for (let itZanr of zanrovi) {
            console.log(itZanr);
        }
    }

    static pronalazenje(poruka = "Unesite ID", zanrovi) {
        this.prikazSvih(zanrovi);

        let id = Konzola.ocitajNumber(poruka);

        let zanr = Bioskop.zanrovi.get(id);
        if (zanr == null) {
            console.log("\n");
            console.log("Žanr nije pronađen!");
        }
        return zanr;
    }

    static prikaz() {
        let zanr = this.pronalazenje();
        if (zanr == null) {
            return;
        }
        console.log("\n");
        console.log(zanr);
    }

    static dodavanje() {
        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }

        let id = Bioskop.nextZanrId();
        let zanr = new Zanr(id, naziv);
        Bioskop.zanrovi.set(id, zanr);

        console.log("\n");
        console.log("Dodavanje uspešno!");
    }

    static izmena() {
        let zanr = this.pronalazenje();
        if (zanr == null) {
            return;
        }
        let naziv = "";
        while (naziv == "") {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        zanr.naziv = naziv;

        console.log("\n");
        console.log("Izmena uspešna!");
    }

    static brisanje() {
        let zanr = this.pronalazenje();
        if (zanr == null) {
            return;
        }
        for (let itFilm of Bioskop.filmovi.values()) {
            if (itFilm.zanrovi.includes(zanr)) {
                console.log("\n");
                console.log("Žanr je povezan!");
                return;
            }
        }

        Bioskop.zanrovi.delete(zanr.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Žanrovi");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");

            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
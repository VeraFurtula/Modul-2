package com.ftninformatika.jwd.modul2.termin7.dostava.dto;

public class ArtikalDTOGet extends ArtikalDTO {

	private RestoranDTOGet restoran;

	public RestoranDTOGet getRestoran() {
		return restoran;
	}

	public void setRestoran(RestoranDTOGet restoran) {
		this.restoran = restoran;
	}

}

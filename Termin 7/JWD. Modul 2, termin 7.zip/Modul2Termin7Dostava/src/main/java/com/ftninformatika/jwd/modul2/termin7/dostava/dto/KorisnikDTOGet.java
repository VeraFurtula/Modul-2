package com.ftninformatika.jwd.modul2.termin7.dostava.dto;

public class KorisnikDTOGet extends KorisnikDTO {}

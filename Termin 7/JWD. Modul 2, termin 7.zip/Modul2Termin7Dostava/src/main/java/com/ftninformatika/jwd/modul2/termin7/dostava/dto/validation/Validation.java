package com.ftninformatika.jwd.modul2.termin7.dostava.dto.validation;

public interface Validation {

	public interface Add {}
	public interface Update {}

}

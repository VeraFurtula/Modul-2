package com.ftninformatika.jwd.modul2.termin7.dostava.dto;

public class KategorijaDTOGet extends KategorijaDTO {}

package com.ftninformatika.jwd.modul2.termin7.bioskop.dto;

public class ZanrDTOGet extends ZanrDTO {}

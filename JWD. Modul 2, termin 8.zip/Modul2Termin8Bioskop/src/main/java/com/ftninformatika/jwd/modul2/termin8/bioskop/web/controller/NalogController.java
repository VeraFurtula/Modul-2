package com.ftninformatika.jwd.modul2.termin8.bioskop.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ftninformatika.jwd.modul2.termin8.bioskop.dto.NalogDTOAddUpdateLogin;
import com.ftninformatika.jwd.modul2.termin8.bioskop.service.NalogService;

@Controller
@RequestMapping("/nalog")
public class NalogController {

	private final NalogService nalogService;

	public NalogController(NalogService nalogService) {
		this.nalogService = nalogService;
	}

	@GetMapping("/prikaz")
	public String get(ModelMap request) {
		request.addAttribute("nalog", nalogService.get());
		return "nalog-prikaz"; // forwarding na template
	}

	@PostMapping("/registracija")
	public String add(@ModelAttribute NalogDTOAddUpdateLogin nalogDTO) {
		nalogService.add(nalogDTO);
		return "redirect:/nalog-prijava.html";
	}

	@PostMapping("/izmena")
	public String update(@ModelAttribute NalogDTOAddUpdateLogin nalogDTO) {
		nalogService.update(nalogDTO);		
		return "redirect:/nalog/prikaz";
	}

	@PostMapping("/prijava")
	public String login(@ModelAttribute NalogDTOAddUpdateLogin nalogDTO) {
		nalogService.login(nalogDTO);
		return "redirect:/nalog/prikaz";
	}

	@PostMapping("/odjava")
	public String logout() {
		nalogService.logout();
		return "redirect:/nalog-prijava.html";
	}

}

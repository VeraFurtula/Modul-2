package com.ftninformatika.jwd.modul2.termin8.bioskop.dto.validation;

public interface Validation {

	public interface Add {}
	public interface Update {}

}

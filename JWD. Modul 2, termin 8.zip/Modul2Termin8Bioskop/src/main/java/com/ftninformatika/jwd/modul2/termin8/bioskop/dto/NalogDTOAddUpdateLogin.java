package com.ftninformatika.jwd.modul2.termin8.bioskop.dto;

import com.ftninformatika.jwd.modul2.termin8.bioskop.dto.validation.Validation;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class NalogDTOAddUpdateLogin extends NalogDTO {

	@NotBlank(message = "Lozinka ne sme biti prazna.", groups = {Validation.Add.class})
	@NotNull(message = "Lozinka nije poslata.", groups = {Validation.Update.class})
	private String lozinka;

	private String ponovljenaLozinka;

	public String getLozinka() {
		return lozinka;
	}

	public void setLozinka(String lozinka) {
		this.lozinka = lozinka;
	}

	public String getPonovljenaLozinka() {
		return ponovljenaLozinka;
	}

	public void setPonovljenaLozinka(String ponovljenaLozinka) {
		this.ponovljenaLozinka = ponovljenaLozinka;
	}

}

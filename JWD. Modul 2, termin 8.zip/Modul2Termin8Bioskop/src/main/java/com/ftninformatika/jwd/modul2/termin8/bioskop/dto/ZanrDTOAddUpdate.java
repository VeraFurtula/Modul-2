package com.ftninformatika.jwd.modul2.termin8.bioskop.dto;

public class ZanrDTOAddUpdate extends ZanrDTO {}

package com.ftninformatika.jwd.modul2.termin8.bioskop.dto;

public class ProjekcijaDTOGet extends ProjekcijaDTO {

	private FilmDTOGet film;

	public FilmDTOGet getFilm() {
		return film;
	}

	public void setFilm(FilmDTOGet film) {
		this.film = film;
	}

}

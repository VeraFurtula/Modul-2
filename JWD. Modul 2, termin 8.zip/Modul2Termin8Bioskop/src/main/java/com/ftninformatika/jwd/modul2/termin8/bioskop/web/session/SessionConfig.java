package com.ftninformatika.jwd.modul2.termin8.bioskop.web.session;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.SessionScope;

import com.ftninformatika.jwd.modul2.termin8.bioskop.model.session.FilmoviIstorija;
import com.ftninformatika.jwd.modul2.termin8.bioskop.model.session.Prijava;
import com.ftninformatika.jwd.modul2.termin8.bioskop.model.session.impl.FilmoviIstorijaBezSortiranja;

//@Configuration
public class SessionConfig {

	@Bean
	@SessionScope
	public FilmoviIstorija filmoviIstorija() {
		return new FilmoviIstorijaBezSortiranja();
	}

	@Bean
	@SessionScope
	public Prijava prijava() {
		return new Prijava();
	}

}

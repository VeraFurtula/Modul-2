package com.ftninformatika.jwd.modul2.termin8.bioskop.dto;

public class KorisnikDTOGet extends KorisnikDTO {}

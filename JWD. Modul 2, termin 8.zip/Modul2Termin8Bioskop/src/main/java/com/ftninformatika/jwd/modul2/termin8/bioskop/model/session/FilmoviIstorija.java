package com.ftninformatika.jwd.modul2.termin8.bioskop.model.session;

import java.util.Collection;

public interface FilmoviIstorija {

	public void addPosecen(long id);
	public void deletePosecen(long id);
	public Collection<Long> getAllPoseceni();

}

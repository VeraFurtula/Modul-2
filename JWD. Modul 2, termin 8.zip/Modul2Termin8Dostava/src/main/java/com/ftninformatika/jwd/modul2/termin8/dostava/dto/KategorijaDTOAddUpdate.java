package com.ftninformatika.jwd.modul2.termin8.dostava.dto;

public class KategorijaDTOAddUpdate extends KategorijaDTO {}

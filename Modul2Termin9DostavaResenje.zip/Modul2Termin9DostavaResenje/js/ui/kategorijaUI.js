class KategorijaUI { 

    static prikazSvih(kategorije) {
        if (kategorije == undefined) {
            kategorije = Array.from(Dostava.kategorije.values()).sort(function(kategorija1, kategorija2) {
                return kategorija1.id - kategorija2.id;
            });
        }
        console.log("\n");
        for (let itKategorija of kategorije) {
            console.log(itKategorija);
        }
    }

    static pronalazenje(poruka = "Unesite ID", kategorije) {
        this.prikazSvih(kategorije);

        let id = Konzola.ocitajNumber(poruka);

        let kategorija = Dostava.kategorije.get(id);
        if (kategorija == null) {
            console.log("\n");
            console.log("Kategorija nije pronađena!");
        }
        return kategorija;
    }

    static prikaz() {
        let kategorija = this.pronalazenje();
        if (kategorija == null) {
            return;
        }
        console.log("\n");
        console.log(kategorija);
    }

    static dodavanje() {
        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }

        let id = Dostava.nextKategorijaId();
        let kategorija = new Kategorija(id, naziv);
        Dostava.kategorije.set(id, kategorija);

        console.log("\n");
        console.log("Dodavanje uspešno!");
    }

    static izmena() {
        let kategorija = this.pronalazenje();
        if (kategorija == null) {
            return;
        }
        let naziv = "";
        while (naziv == "") {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        kategorija.naziv = naziv;

        console.log("\n");
        console.log("Izmena uspešna!");
    }

    static brisanje() {
        let kategorija = this.pronalazenje();
        if (kategorija == null) {
            return;
        }
        for (let itRestoran of Dostava.restorani.values()) {
            if (itRestoran.kategorije.includes(kategorija)) {
                console.log("\n");
                console.log("Žanr je povezan!");
                return;
            }
        }

        Dostava.kategorije.delete(kategorija.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Kategorije");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");

            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
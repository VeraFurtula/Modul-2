class ArtikalUI { 

    static prikazSvih(artikli) {
        if (artikli == undefined) {
            artikli = Array.from(Dostava.artikli.values()).sort(function(artikal1, artikal2) {
                return artikal1.id - artikal2.id;
            });
        }
        console.log("\n");
        for (let itArtikal of artikli) {
            console.log(itArtikal);
        }
    }

    static pronalazenje(poruka = "Unesite ID", artikli) {
        this.prikazSvih(artikli);

        let id = Konzola.ocitajNumber(poruka);

        let artikal = Dostava.artikli.get(id);
        if (artikal == null) {
            console.log("\n");
            console.log("Artikal nije pronađen!");
        }
        return artikal;
    }

    static prikaz() {
        let artikal = this.pronalazenje();
        if (artikal == null) {
            return;
        }
        console.log("\n");
        console.log(artikal);
    }

    static dodavanje() {
        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let opis = null;
        while (opis == null) {
            opis = Konzola.ocitajString("Unesite opis");
        }
        let cena = null;
        while (cena == null) {
            cena = Konzola.ocitajNumber("Unesite cena");
        }
        let restoran = null;
        while (restoran == null) {
            restoran = RestoranUI.pronalazenje("Unesite ID restorana"); // many-to-one
        }

        let id = Dostava.nextArtikalId();
        let artikal = new Artikal(id, naziv, opis, cena, restoran);
        Dostava.artikli.set(id, artikal);

        console.log("\n");
        console.log("Dodavanje uspešno!");
    }

    static izmena() {
        let artikal = this.pronalazenje();
        if (artikal == null) {
            return;
        }

        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let opis = null;
        while (opis == null) {
            opis = Konzola.ocitajString("Unesite opis");
        }
        let cena = null;
        while (cena == null) {
            cena = Konzola.ocitajNumber("Unesite cena");
        }
        let restoran = null;
        while (restoran == null) {
            restoran = RestoranUI.pronalazenje("Unesite ID restorana"); // many-to-one
        }
        artikal.naziv = naziv;
        artikal.opis = opis;
        artikal.cena = cena;
        artikal.restoran = restoran;

        console.log("\n");
        console.log("Izmena uspešna!");
    }

    static brisanje() {
        let artikal = this.pronalazenje();
        if (artikal == null) {
            return;
        }
        Dostava.artikli.delete(artikal.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Artikli");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");
    
            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
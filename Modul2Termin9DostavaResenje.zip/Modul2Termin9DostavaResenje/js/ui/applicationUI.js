class ApplicationUI {

    static meni() {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n")
            console.log("Dostava");
            console.log("-------------");
            console.log("0. Izlaz");
            console.log("1. Kategorije");
            console.log("2. Restorani");
            console.log("3. Artikli");
            console.log("-------------");
    
            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    KategorijaUI.meni();
                    break;
                }
                case "2": {
                    RestoranUI.meni();
                    break;
                }
                case "3": {
                    ArtikalUI.meni();
                    break;
                }
            }
        }
    }

}

ApplicationUI.meni();
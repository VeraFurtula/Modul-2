class RestoranUI { 

    static prikazSvih(restorani) {
        if (restorani == undefined) {
            restorani = Array.from(Dostava.restorani.values()).sort(function(restoran1, restoran2) {
                return restoran1.id - restoran2.id;
            });
        }
        console.log("\n");
        for (let itRestoran of restorani) {
            console.log(itRestoran);
        }
    }

    static pronalazenje(poruka = "Unesite ID", restorani) {
        this.prikazSvih(restorani);

        let id = Konzola.ocitajNumber(poruka);

        let restoran = Dostava.restorani.get(id);
        if (restoran == null) {
            console.log("\n");
            console.log("Restoran nije pronađen!");
        }
        return restoran;
    }

    static prikaz() {
        let restoran = this.pronalazenje();
        if (restoran == null) {
            return;
        }
        console.log("\n");
        console.log(restoran);
    }

    static dodavanje() {
        let naziv = null;
        while (naziv == null) {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let datumOsnivanja = null;
        while (datumOsnivanja == null || datumOsnivanja > Date.now()) {
            datumOsnivanja = Konzola.ocitajDate("Unesite datum osnivanja");
        }
        let id = Dostava.nextRestoranId();
        let restoran = new Restoran(id, naziv, datumOsnivanja);
        Dostava.restorani.set(id, restoran);

        console.log("\n");
        console.log("Dodavanje uspešno!");

        // many-to-many
        let nedostajuceKategorije = restoran.findNedostajuceKategorije(Dostava.kategorije.values());
        while (nedostajuceKategorije.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da dodate kategoriju")) {
			let kategorija = KategorijaUI.pronalazenje("Unesite ID kategorije", nedostajuceKategorije);
			if (kategorija == null) {
				continue;
            }
            restoran.addKategorija(kategorija);

            console.log("\n");
            console.log("Kategorija je dodata!");	
            
            nedostajuceKategorije = restoran.findNedostajuceKategorije(Dostava.kategorije.values())
		}
    }

    static izmena() {
        let restoran = this.pronalazenje();
        if (restoran == null) {
            return;
        }

        let naziv = "";
        while (naziv == "") {
            naziv = Konzola.ocitajString("Unesite naziv");
        }
        let datumOsnivanja = null;
        while (datumOsnivanja == null || datumOsnivanja > Date.now()) {
            datumOsnivanja = Konzola.ocitajDate("Unesite datum osnivanja");
        }
        restoran.naziv = naziv;
        restoran.datumOsnivanja = datumOsnivanja;

        console.log("\n");
        console.log("Izmena uspešna!");

         // many-to-many
        while (restoran.kategorije.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da uklonite kategoriju")) {
			let kategorija = KategorijaUI.pronalazenje("Unesite ID kategorije", restoran.kategorije);
			if (kategorija == null) {
				continue;
            }
            restoran.removeKategorija(kategorija);

            console.log("\n");
            console.log("Kategorija je uklonjena!");		
		}
        let nedostajuceKategorije = restoran.findNedostajuceKategorije(Dostava.kategorije.values());
        while (nedostajuceKategorije.length > 0 && 
                Konzola.ocitajBoolean("Da li zelite da dodate kategoriju")) {
			let kategorija = KategorijaUI.pronalazenje("Unesite ID kategorije", nedostajuceKategorije);
			if (kategorija == null) {
				continue;
            }
            restoran.addKategorija(kategorija);

            console.log("\n");
            console.log("Kategorija je uklonjena!");	
            
            nedostajuceKategorije = restoran.findNedostajuceKategorije(Dostava.kategorije.values())
		}
    }

    static brisanje() {
        let restoran = this.pronalazenje();
        if (restoran == null) {
            return;
        }
        for (let itArtikal of Dostava.artikli.values()) {
            if (itArtikal.restoran == restoran) {
                console.log("\n");
                console.log("Restoran je povezan!");
                return;
            }
        }

        Dostava.restorani.delete(restoran.id);

        console.log("\n");
        console.log("Brisanje uspešno!");
    }

    static meni () {
        let izbor = -1;
        while (izbor != 0) {
            console.log("\n");
            console.log("Restorani");
            console.log("--------------");
            console.log("0. Povratak");
            console.log("1. Prikaz svih");
            console.log("2. Prikaz");
            console.log("3. Dodavanje");
            console.log("4. Izmena");
            console.log("5. Brisanje");
            console.log("--------------");

            izbor = Konzola.ocitajString("Unesite izbor");
            switch (izbor) {
                case "1": {
                    this.prikazSvih();
                    break;
                }
                case "2": {
                    this.prikaz();
                    break;
                }
                case "3": {
                    this.dodavanje();
                    break;
                }
                case "4": {
                    this.izmena();
                    break;
                }
                case "5": {
                    this.brisanje();
                    break;
                }
            }
        }
    }

}
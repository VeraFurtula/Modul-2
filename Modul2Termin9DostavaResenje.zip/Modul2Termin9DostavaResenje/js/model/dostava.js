class Dostava {
    static kategorije = new Map();
    static restorani = new Map();
    static artikli = new Map();

	static maxKategorijaId;
	static maxRestoranId;
	static maxArtikalId;

    static inicijalizuj() {
		// kreiranje kategorija
		this.kategorije.set(1, new Kategorija(1, "Burgeri"));
		this.kategorije.set(2, new Kategorija(2, "Sendviči"));
		this.kategorije.set(3, new Kategorija(3, "Suši"));
		this.kategorije.set(4, new Kategorija(4, "Onigiri"));
		this.kategorije.set(5, new Kategorija(5, "Burito"));

		// kreiranje restorana
		this.restorani.set(1, new Restoran(1, "Restoran 1", new Date("2001-01-01")));
		this.restorani.set(2, new Restoran(2, "Restoran 2", new Date("2012-02-01")));
		this.restorani.set(3, new Restoran(3, "Restoran 3", new Date("2023-03-01")));

		// povezivanje restorana i kategorija
		this.restorani.get(1).addKategorija(this.kategorije.get(1));
		this.restorani.get(1).addKategorija(this.kategorije.get(2));
		this.restorani.get(2).addKategorija(this.kategorije.get(3));
		this.restorani.get(2).addKategorija(this.kategorije.get(4));
		this.restorani.get(3).addKategorija(this.kategorije.get(5));

		// kreiranje i artikala i povezivanje artikala i restorana
		this.artikli.set(1, new Artikal(1, "Dupli burger", "Burger meso 120 grama, toljeni sir, burger majonez, heinz kečap, ajsberg, kiseli krastavac", 650, this.restorani.get(1)));
		this.artikli.set(2, new Artikal(2, "Pileći burger", "Pileći burger, tost sir, pančeta, burger majonez, ajsberg, paradajz", 550, this.restorani.get(1)));
		this.artikli.set(3, new Artikal(3, "Indeks sendvič", "Praška šunka, sir, šampinjoni", 320, this.restorani.get(1)));
		this.artikli.set(4, new Artikal(4, "Vratolomija sendvič", "Suvi vrat, sir, jaja", 290, this.restorani.get(1)));	
		this.artikli.set(5, new Artikal(5, "Crispy specijal", "Hrskave sushi rolnice, pohovane u tempuri. Nori alga, pirinač, pohovana rolnica sa dodatkom krastavca, krem sira, lososa i japanskog nitsume sosa", 920, this.restorani.get(2)));
		this.artikli.set(6, new Artikal(6, "Samurai roll", "8 komada, nori alga, pirinač, losos, tuna, avokado, obložena breniranim lososom i tunom,unagi sos, samuraj sos, hrskavi crunch krompir", 990, this.restorani.get(2)));
		this.artikli.set(7, new Artikal(7, "Onigiri sa tunom", "pirinač, tuna, crni susam, japanski majonez i nori alge", 510, this.restorani.get(2)));
		this.artikli.set(8, new Artikal(8, "Onigiri sa lososom", "pirinač, losos, crni susam, japanski majonez i nori alge", 670, this.restorani.get(2)));
		this.artikli.set(9, new Artikal(9, "Achiote piletina burito", "Meksički pirinač, Crni pasulj, Mokahete Salsa, Pico de gallo, Kukuruz salsa, Marinirani Krastavac, Kačkavalj, Crema Fresca", 560, this.restorani.get(3)));
		this.artikli.set(10, new Artikal(10, "Chorizo burito", "Meksički pirinač, Pinto pasulj, Mokahete Salsa, Pico de gallo, Kukuruz Salsa, Kačkavalj, Marinirani krastavac, Marinirani crveni luk, Chipotle aioli", 610, this.restorani.get(3)));
		this.artikli.set(11, new Artikal(11, "Pečene pečurke burito", "Beli pirinač, Crni pasulj, Pečene pečurke, Pico de gallo, Kukuruz salsa, Marinirani krastavac, Mokahete salsa, Mix zelenih salata, Krema Freska", 480, this.restorani.get(3)));

        this.maxKategorijaId = 5;
        this.maxRestoranId = 4;
        this.maxArtikalId = 10;
    }

    static nextKategorijaId() {
        this.maxKategorijaId++;
        return this.maxKategorijaId;
    }

    static nextRestoranId() {
        this.maxRestoranId++;
        return this.maxRestoranId;
    }

    static nextArtikalId() {
        this.maxArtikalId++;
        return this.maxArtikalId;
    }

}

Dostava.inicijalizuj();

class Artikal {

    constructor(id, naziv, opis, cena, restoran) {
        this.id = id;
        this.naziv = naziv;
        this.opis = opis;
        this.cena = cena;
        this.restoran = restoran;
    }

}
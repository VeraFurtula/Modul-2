class Restoran {

    constructor(id, naziv, datumOsnivanja) {
        this.id = id;
        this.naziv = naziv;
        this.datumOsnivanja = datumOsnivanja;

        this.kategorije = [];
    }

    addKategorija(kategorija) {
        if (this.kategorije.includes(kategorija)) {
            return;
        }
        this.kategorije.push(kategorija);
    }

    removeKategorija(kategorija) {
        let index = this.kategorije.indexOf(kategorija);
        if (index > -1) {
            this.kategorije.splice(index, 1);
        }
    }

    findNedostajuceKategorije(kategorije) {
        let rezultat = [];
        for (let itKategorija of kategorije) {
            if (!this.kategorije.includes(itKategorija)) {
                rezultat.push(itKategorija);
            }
        }
        return rezultat;
    }
}
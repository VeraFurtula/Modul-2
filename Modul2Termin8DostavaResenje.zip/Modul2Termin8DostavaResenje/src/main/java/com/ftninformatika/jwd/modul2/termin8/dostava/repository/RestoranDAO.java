package com.ftninformatika.jwd.modul2.termin8.dostava.repository;

import java.time.LocalDate;
import java.util.Collection;

import com.ftninformatika.jwd.modul2.termin8.dostava.model.Restoran;

public interface RestoranDAO {

	public Restoran get(long id);
	public Collection<Restoran> getAll();
	public Collection<Restoran> get(String naziv, long kategorijaId, LocalDate datumOsnivanjaOd, LocalDate datumOsnivanjaDo);
	public void add(Restoran restoran);
	public void update(Restoran restoran);
	public void delete(long id);

}

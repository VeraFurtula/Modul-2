package com.ftninformatika.jwd.modul2.termin8.dostava.web.interceptor;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.ftninformatika.jwd.modul2.termin8.dostava.service.NalogService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class AutorizacijaInterceptor implements HandlerInterceptor {

	private final NalogService nalogService;

	public AutorizacijaInterceptor(NalogService nalogService) {
		this.nalogService = nalogService;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String resurs = request.getRequestURI();
		HttpMethod metoda = HttpMethod.valueOf(request.getMethod());
		boolean ovlascen = nalogService.isAuthorized(resurs, metoda);

		/*
		System.out.println();
		System.out.println("Autorizacija - resurs: " + resurs);
		System.out.println("Autorizacija - metoda: " + metoda);
		System.out.println("Autorizacija - dozvoljen: " + ovlascen);
		*/
		if (!ovlascen) {
			response.sendRedirect("/nalog-prijava.html");
			return false;
		}
		return true;
	}

}

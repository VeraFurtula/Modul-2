package com.ftninformatika.jwd.modul2.termin8.dostava.web.interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

	private final AutorizacijaInterceptor autorizacijaInterceptor;

	public InterceptorConfig(AutorizacijaInterceptor autorizacijaInterceptor) {
		this.autorizacijaInterceptor = autorizacijaInterceptor;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(autorizacijaInterceptor).addPathPatterns(
				"/korisnici/**", 
				"/kategorije/**", 
				"/restorani/**", 
				"/artikli/**");
	}

}

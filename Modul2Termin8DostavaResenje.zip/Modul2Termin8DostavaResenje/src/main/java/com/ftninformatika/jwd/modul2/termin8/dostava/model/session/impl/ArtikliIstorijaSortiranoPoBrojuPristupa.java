package com.ftninformatika.jwd.modul2.termin8.dostava.model.session.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import com.ftninformatika.jwd.modul2.termin8.dostava.model.session.ArtikliIstorija;

@Primary
@Component
@SessionScope
@SuppressWarnings("serial")
public class ArtikliIstorijaSortiranoPoBrojuPristupa implements Serializable, ArtikliIstorija {

	private static class Brojac implements Serializable {

		private final long artikalId;
		private int brojPristupa = 0;

		public Brojac(long artikalId) {
			this.artikalId = artikalId;
		}

		public void increment() {
			brojPristupa++;
		}
		
		public long getArtikalId() {
			return artikalId;
		}

		public int getBrojPristupa() {
			return brojPristupa;
		}

	}
	
	private static final int KAPACITET = 5;

	private final Map<Long, Brojac> brojaci = new HashMap<>();

	private List<Brojac> sortirajBrojace() {
		List<Brojac> brojaci = new ArrayList<>(this.brojaci.values());
		
		Comparator<Brojac> comp = new Comparator<>() {

			@Override
			public int compare(Brojac brojac1, Brojac brojac2) {
				return Integer.compare(brojac1.getBrojPristupa(), brojac2.getBrojPristupa());
			}
			
		};
		brojaci.sort(comp.reversed()); // sortirani brojaci po opadajućem redosledu broja pristupa
		return brojaci;
	}

	@Override
	public void addPosecen(long id) {
		Brojac brojac = brojaci.get(id); // da li već postoji brojač za posećeni artikal
		if (brojac == null) {
			// dodavanje novog brojača za posećeni artikal
			brojac = new Brojac(id);
			brojaci.put(id, brojac);
		}
		brojac.increment();
	}

	@Override
	public void deletePosecen(long id) {
		brojaci.remove(id);
	}

	@Override
	public Collection<Long> getAllPoseceni() {
		List<Brojac> sortiraniBrojaci = sortirajBrojace();

		List<Long> poseceniIDs = new ArrayList<>();
		for (Brojac itBrojac: sortiraniBrojaci) { // izdvajanje id-eva artiklala iz sortiranih brojača
			poseceniIDs.add(itBrojac.getArtikalId());
		}
		if (poseceniIDs.size() > KAPACITET) {
			return poseceniIDs.subList(0, KAPACITET);
		}
		return Collections.unmodifiableCollection(poseceniIDs);
	}

}

package com.ftninformatika.jwd.modul2.termin8.dostava.service;

import org.springframework.http.HttpMethod;

import com.ftninformatika.jwd.modul2.termin8.dostava.dto.NalogDTOAddUpdateLogin;
import com.ftninformatika.jwd.modul2.termin8.dostava.dto.NalogDTOGet;

import jakarta.validation.Valid;

public interface NalogService {

	public NalogDTOGet get();
	public void add(@Valid NalogDTOAddUpdateLogin nalogDTO);
	public void update(@Valid NalogDTOAddUpdateLogin nalogDTO);

	public void login(NalogDTOAddUpdateLogin nalogDTO);
	public void logout();
	public boolean isAuthorized(String resurs, HttpMethod metoda);

}

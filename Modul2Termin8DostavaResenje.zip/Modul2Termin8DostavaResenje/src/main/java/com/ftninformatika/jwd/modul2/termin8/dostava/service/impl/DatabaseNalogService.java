package com.ftninformatika.jwd.modul2.termin8.dostava.service.impl;

import java.util.NoSuchElementException;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.ftninformatika.jwd.modul2.termin8.dostava.dto.NalogDTOAddUpdateLogin;
import com.ftninformatika.jwd.modul2.termin8.dostava.dto.NalogDTOGet;
import com.ftninformatika.jwd.modul2.termin8.dostava.dto.validation.Validation;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.Korisnik;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.session.Prijava;
import com.ftninformatika.jwd.modul2.termin8.dostava.repository.KorisnikDAO;
import com.ftninformatika.jwd.modul2.termin8.dostava.service.NalogService;

import jakarta.validation.Valid;

@Service
@Validated
public class DatabaseNalogService implements NalogService {

	private final KorisnikDAO korisnikDAO;
	private final ModelMapper mapper = new ModelMapper();

	private Prijava prijava; // sesssion
	
	public DatabaseNalogService(KorisnikDAO korisnikDAO, Prijava prijava) {
		this.korisnikDAO = korisnikDAO;
		
		this.prijava = prijava;
	}

	private NalogDTOGet createDTO(Korisnik korisnik) {
		return mapper.map(korisnik, NalogDTOGet.class);
	}

	@Override
	public NalogDTOGet get() {
		String korisnickoIme = prijava.getKorisnickoIme(); // session
		if (korisnickoIme == null) {
			throw new IllegalStateException("Niste prijavljeni!");
		}
		Korisnik korisnik = korisnikDAO.get(korisnickoIme);
		if (korisnik == null) {
			throw new NoSuchElementException("Vaš nalog nije pronađen!");
		}
		return createDTO(korisnik);
	}

	@Override
	@Validated(Validation.Add.class)
	public void add(@Valid NalogDTOAddUpdateLogin nalogDTO) {
		if (!nalogDTO.getLozinka().equals(nalogDTO.getPonovljenaLozinka())) {
			throw new IllegalArgumentException("Lozinke se ne podudaraju!");
		}
		Korisnik korisnik = mapper.map(nalogDTO, Korisnik.class);
		korisnikDAO.add(korisnik);
	}

	@Override
	@Validated(Validation.Update.class)
	public void update(@Valid NalogDTOAddUpdateLogin nalogDTO) {
		if (!nalogDTO.getLozinka().equals(nalogDTO.getPonovljenaLozinka())) {
			throw new IllegalArgumentException("Lozinke se ne podudaraju!");
		}
		String korisnickoIme = prijava.getKorisnickoIme(); // session
		if (korisnickoIme == null) {
			throw new IllegalStateException("Niste prijavljeni!");
		}
		Korisnik korisnik = korisnikDAO.get(korisnickoIme);
		if (!nalogDTO.getLozinka().equals("")) { // lozinka se menja samo ako je unesena; zbog ovog uslova se ne koristi mapper jer bi on bezuslovno prekopirao lozinku
			korisnik.setLozinka(nalogDTO.getLozinka());
		}
		korisnik.seteMail(nalogDTO.geteMail());
		korisnik.setPol(nalogDTO.getPol());

		korisnikDAO.update(korisnik);
	}

	@Override
	public void login(NalogDTOAddUpdateLogin nalogDTO) {
		Korisnik korisnik = korisnikDAO.get(nalogDTO.getKorisnickoIme(), nalogDTO.getLozinka());
		if (korisnik == null) {
			throw new IllegalArgumentException("Neuspešna prijava!");
		}
		prijava.setKorisnickoIme(korisnik.getKorisnickoIme());
	}

	@Override
	public void logout() {
		prijava.setKorisnickoIme(null); // session
	}

	@Override
	public boolean isAuthorized(String resurs, HttpMethod metoda) {		
		// uvek dozvoljeno
		if (resurs.contains("/kategorije") && !resurs.contains("/dodavanje") && metoda.equals(HttpMethod.GET)) {
			return true;
		}
		if (resurs.contains("/restorani") && !resurs.contains("/dodavanje") && metoda.equals(HttpMethod.GET)) {
			return true;
		}
		if (resurs.contains("/artikli") && !resurs.contains("/dodavanje") && metoda.equals(HttpMethod.GET)) {
			return true;
		}

		// zahteva ovlašćenje
		String korisnickoIme = prijava.getKorisnickoIme(); // session
		if (korisnickoIme == null) {
			return false;
		}
		Korisnik korisnik = korisnikDAO.get(korisnickoIme);
		if (korisnik == null) {
			return false;
		}
		return korisnik.isAdministrator();
	}

}

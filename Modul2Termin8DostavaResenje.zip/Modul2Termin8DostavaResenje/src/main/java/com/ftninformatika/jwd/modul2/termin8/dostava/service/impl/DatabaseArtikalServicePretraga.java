package com.ftninformatika.jwd.modul2.termin8.dostava.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.ftninformatika.jwd.modul2.termin8.dostava.dto.ArtikalDTOAddUpdate;
import com.ftninformatika.jwd.modul2.termin8.dostava.dto.ArtikalDTOGet;
import com.ftninformatika.jwd.modul2.termin8.dostava.dto.validation.Validation;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.Artikal;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.Restoran;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.session.ArtikliIstorija;
import com.ftninformatika.jwd.modul2.termin8.dostava.model.session.impl.ArtikliIstorijaBezSortiranja;
import com.ftninformatika.jwd.modul2.termin8.dostava.repository.ArtikalDAO;
import com.ftninformatika.jwd.modul2.termin8.dostava.repository.RestoranDAO;
import com.ftninformatika.jwd.modul2.termin8.dostava.service.ArtikalService;

import jakarta.validation.Valid;

//@Primary
@Service
@Validated
public class DatabaseArtikalServicePretraga implements ArtikalService {

	private final ArtikalDAO artikalDAO;
	private final RestoranDAO restoranDAO;
	private final ModelMapper mapper = new ModelMapper();

	private ArtikliIstorija artikliIstorija; // session

	public DatabaseArtikalServicePretraga(ArtikalDAO artikalDAO, RestoranDAO restoranDAO, ArtikliIstorija artikliIstorija) {
		this.artikalDAO = artikalDAO;
		this.restoranDAO = restoranDAO;
		this.artikliIstorija = artikliIstorija;
	}

	private ArtikalDTOGet createDTO(Artikal artikal) {
		return mapper.map(artikal, ArtikalDTOGet.class);
	}

	private Collection<ArtikalDTOGet> createDTO(Collection<Artikal> artikli) {
		Collection<ArtikalDTOGet> artikalDTOs = new ArrayList<>();
		for (Artikal itArtikal: artikli) {
			ArtikalDTOGet artikalDTO = createDTO(itArtikal);
			artikalDTOs.add(artikalDTO);
		}
		return artikalDTOs;
	}

	@Override
	public ArtikalDTOGet get(long id) {
		Artikal artikal = artikalDAO.get(id);
		if (artikal == null) {
			throw new NoSuchElementException("Artikal nije pronađen!");
		}
		artikliIstorija.addPosecen(id); // session

		return createDTO(artikal);
	}

	@Override
	public Collection<ArtikalDTOGet> getAll() {
		Collection<Artikal> artikli = artikalDAO.getAll();
		return createDTO(artikli);
	}

	@Override
	public Collection<ArtikalDTOGet> get(String naziv, String opis, double cenaOd, double cenaDo, long restoranId) {
		Collection<Artikal> artikli = artikalDAO.getAll();

		List<Artikal> rezultat = new ArrayList<>();
		for (Artikal itArtikal: artikli) {
			if ((naziv == null || itArtikal.getNaziv().toLowerCase().contains(naziv.toLowerCase())) && 
					(opis == null || itArtikal.getOpis().toLowerCase().contains(opis.toLowerCase())) &&
					(cenaOd <= 0 || itArtikal.getCena() >= cenaOd) && 
					(cenaDo <= 0 || itArtikal.getCena() <= cenaDo) &&
					(restoranId <= 0 || itArtikal.getRestoran().getId() == restoranId)) {
				rezultat.add(itArtikal);
			}
		}
		return createDTO(rezultat);
	}

	@Override
	@Validated(Validation.Add.class)
	public void add(@Valid ArtikalDTOAddUpdate artikalDTO) {
		Restoran restoran = restoranDAO.get(artikalDTO.getRestoranId()); // pronalaženje restorana po id
		if (restoran == null) { // da li je restoran pronađen?
			throw new NoSuchElementException("Restoran nije pronađen!"); // spreči dodavanje
		}
		Artikal artikal = mapper.map(artikalDTO, Artikal.class);
		artikal.setRestoran(restoran); // povezivanje

		artikalDAO.add(artikal);
	}

	@Override
	@Validated(Validation.Update.class)
	public void update(@Valid ArtikalDTOAddUpdate artikalDTO) {
		Restoran restoran = restoranDAO.get(artikalDTO.getRestoranId()); // pronalaženje restorana po id
		if (restoran == null) { // da li je restoran pronađen?
			throw new NoSuchElementException("Restoran nije pronađen!"); // spreči dodavanje
		}
		Artikal artikal = mapper.map(artikalDTO, Artikal.class);
		artikal.setRestoran(restoran); // povezivanje

		artikalDAO.update(artikal);
	}

	@Override
	public void delete(long id) {
		artikalDAO.delete(id);
		artikliIstorija.deletePosecen(id); // session
	}

	@Override
	public Collection<ArtikalDTOGet> getPoseceni() {
		Collection<Long> poseceniArtikliIDs = artikliIstorija.getAllPoseceni(); // session

		List<Artikal> poseceniArtikli = new ArrayList<>();
		for (Long itFilmID: poseceniArtikliIDs) {
			poseceniArtikli.add(artikalDAO.get(itFilmID));
		}
		return createDTO(poseceniArtikli);
	}

}

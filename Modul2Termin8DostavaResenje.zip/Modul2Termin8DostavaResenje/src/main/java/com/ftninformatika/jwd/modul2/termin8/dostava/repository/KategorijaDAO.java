package com.ftninformatika.jwd.modul2.termin8.dostava.repository;

import java.util.Collection;

import com.ftninformatika.jwd.modul2.termin8.dostava.model.Kategorija;

public interface KategorijaDAO {

	public Kategorija get(long id);
	public Collection<Kategorija> getAll();
	public Collection<Kategorija> get(String naziv);
	public void add(Kategorija kategorija);
	public void update(Kategorija kategorija);
	public void delete(long id);

}

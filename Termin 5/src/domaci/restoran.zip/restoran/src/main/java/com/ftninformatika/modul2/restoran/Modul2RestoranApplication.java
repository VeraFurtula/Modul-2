package com.ftninformatika.modul2.restoran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modul2RestoranApplication {

	public static void main(String[] args) {
		SpringApplication.run(Modul2RestoranApplication.class, args);
	}

}

package com.ftninformatika.modul2.restoran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modul2RestoranApplicationTests {

	@Test
	void contextLoads() {
	}

}

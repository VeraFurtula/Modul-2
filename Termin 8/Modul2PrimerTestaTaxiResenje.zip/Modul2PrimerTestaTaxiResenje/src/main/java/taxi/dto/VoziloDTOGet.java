package taxi.dto;

public class VoziloDTOGet extends VoziloDTO {}

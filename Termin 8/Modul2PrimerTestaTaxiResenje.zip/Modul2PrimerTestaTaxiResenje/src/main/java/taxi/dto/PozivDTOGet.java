package taxi.dto;

public class PozivDTOGet extends PozivDTO {

	private VoziloDTOGet vozilo;

	public VoziloDTOGet getVozilo() {
		return vozilo;
	}

	public void setVozilo(VoziloDTOGet vozilo) {
		this.vozilo = vozilo;
	}

}

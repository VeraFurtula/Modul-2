package taxi.dto.validation;

public interface Validation {

	public interface Add {}
	public interface Update {}

}

package taxi.service;

import java.util.Collection;

import taxi.dto.VoziloDTOGet;

public interface VoziloService {

	public Collection<VoziloDTOGet> getAll();

}

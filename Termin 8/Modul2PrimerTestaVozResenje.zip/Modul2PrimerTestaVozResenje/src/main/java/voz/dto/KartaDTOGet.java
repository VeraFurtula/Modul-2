package voz.dto;

public class KartaDTOGet extends KartaDTO {

	private VozDTOGet voz;

	public VozDTOGet getVoz() {
		return voz;
	}

	public void setVoz(VozDTOGet voz) {
		this.voz = voz;
	}

}

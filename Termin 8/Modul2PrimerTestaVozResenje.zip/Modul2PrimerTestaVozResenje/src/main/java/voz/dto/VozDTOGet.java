package voz.dto;

public class VozDTOGet extends VozDTO {}

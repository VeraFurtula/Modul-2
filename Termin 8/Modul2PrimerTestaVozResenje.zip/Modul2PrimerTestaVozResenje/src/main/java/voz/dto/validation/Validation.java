package voz.dto.validation;

public interface Validation {

	public interface Add {}
	public interface Update {}

}

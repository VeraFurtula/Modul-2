package voz.service;

import java.util.Collection;

import voz.dto.VozDTOGet;

public interface VozService {

	public Collection<VozDTOGet> getAll();

}

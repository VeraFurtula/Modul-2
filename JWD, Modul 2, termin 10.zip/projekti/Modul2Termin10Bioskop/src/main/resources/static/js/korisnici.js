/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let tbody = document.querySelector("tbody");

	let buttonsSortKorisnickoIme = document.querySelectorAll("button.sort-korisnickoIme");
	let buttonsSortEMail = document.querySelectorAll("button.sort-eMail");
	let buttonsSortPol = document.querySelectorAll("button.sort-pol");
	let buttonsSortAdministrator = document.querySelectorAll("button.sort-administrator");

	// funkcija za sortiranje tabele po prosleđenom komparatoru
	function sortTBody(comp) {
		// pravljenje niza od kolekcije HTML elemenata
		let redovi = Array.of(...tbody.children); // ... unpack operator
		redovi.sort(comp);

		// pražnjenje tabele
		while (tbody.children.length > 0) {
			tbody.children[0].remove();
		}
		// popunjavanje tabele u sortiranom redosledu redova
		for (let it in redovi) {
			let red = redovi[it];
			red.children[0].textContent = Number(it) + 1; // ažuriranje rednog broja
			tbody.append(red);
		}
	}

	// funkcije za sortiranje po koloni
	function sortKorisnickoIme(smer) {
		sortTBody(function(red1, red2) {
			let korisnickoIme1 = red1.children[1].children[0].textContent; // tr -> td -> a.textContent
			let korisnickoIme2 = red2.children[1].children[0].textContent;
			return smer*(korisnickoIme1.localeCompare(korisnickoIme2));
		});
	}
	function sortEMail(smer) {
		sortTBody(function(red1, red2) {
			let eMail1 = red1.children[2].textContent; // tr -> td.textContent
			let eMail2 = red2.children[2].textContent;
			return smer*(eMail1.localeCompare(eMail2));
		});
	}
	function sortPol(smer) {
		sortTBody(function(red1, red2) {
			let pol1 = red1.children[3].textContent; // tr -> td.textContent
			let pol2 = red2.children[3].textContent;
			return smer*(pol1.localeCompare(pol2));
		});
	}
	function sortAdministrator(smer) {
		sortTBody(function(red1, red2) {
			let administrator1 = red1.children[4].textContent; // tr -> td.textContent
			let administrator2 = red2.children[4].textContent;
			return smer*(administrator1.localeCompare(administrator2));
		});
	}

	// registracija događaja
	buttonsSortKorisnickoIme[0].onclick = function(event) { // event parametar je opisnik događaja
		sortKorisnickoIme(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortKorisnickoIme[1].onclick = function(event) { // event parametar je opisnik događaja
		sortKorisnickoIme(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortEMail[0].onclick = function(event) { // event parametar je opisnik događaja
		sortEMail(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortEMail[1].onclick = function(event) { // event parametar je opisnik događaja
		sortEMail(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortPol[0].onclick = function(event) { // event parametar je opisnik događaja
		sortPol(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortPol[1].onclick = function(event) { // event parametar je opisnik događaja
		sortPol(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortAdministrator[0].onclick = function(event) { // event parametar je opisnik događaja
		sortAdministrator(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortAdministrator[1].onclick = function(event) { // event parametar je opisnik događaja
		sortAdministrator(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
}
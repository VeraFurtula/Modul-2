/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	 // da li je skripta pokrenuta na stranici za prikaz?
	let prikaz = document.querySelectorAll("form").length > 1; // da li ima više od jedne forme (izmena i dodavanje)

	// keširanje referenci na elemente stranice
	let korisnickoIme = document.querySelector("input[name=korisnickoIme]");
	let lozinka = document.querySelector("input[name=lozinka]");
	let eMail = document.querySelector("input[name=eMail]");
	let pol = document.querySelectorAll("input[name=pol]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaKorisnickoIme() {
		return korisnickoIme.value.match("^[a-zA-Z0-9]+$") != null; // input.value
	}
	function validacijaLozinka() {
		return lozinka.value != ""; // input.value
	}
	function validacijaEMail() {
		return eMail.value.match("^[a-zA-Z0-9]+@[a-zA-Z0-9]+.com$") != null; // input.value
	}
	function validacijaPol() {
		let odabran = false;
		for (let itPol of pol) {
			if (itPol.checked) { // input.checked (funkcioniše za checkbox i radio)
				odabran = true;
				break;
			}
		}
		return odabran;
	}
	function validacija() {
		return validacijaKorisnickoIme() && (prikaz || validacijaLozinka()) && validacijaEMail() && validacijaPol();
	}

	// registracija handler-a na događaje promene unosa input-a
	let korisnickoImeCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaKorisnickoIme()? "": "Korisničko ime ne sme biti prazno i sme da sadrži samo slova i cifre!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	korisnickoIme.onchange = korisnickoImeCallback;
	korisnickoIme.onblur = korisnickoImeCallback;
	korisnickoIme.onkeyup = korisnickoImeCallback;

	let lozinkaCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = (prikaz || validacijaLozinka())? "": "Lozinka ne sme biti prazna!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	lozinka.onchange = lozinkaCallback;
	lozinka.onblur = lozinkaCallback;
	lozinka.onkeyup = lozinkaCallback;

	let eMailCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaEMail()? "": "E-mail nije u odgovarajućem obliku!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	eMail.onchange = eMailCallback;
	eMail.onblur = eMailCallback;
	eMail.onkeyup = eMailCallback;

	let polCallback = function(event) {
		// prikaz poruke
		let error = event.target.parentElement.parentElement.lastElementChild; // input -> div -> div -> small
		error.textContent = validacijaPol()? "": "Pol nije odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	for (let itPol of pol) { // registracija handler-a na oba radio-a
		itPol.onchange = polCallback;
		itPol.onblur = polCallback;
		itPol.onkeyup = polCallback;
	}

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


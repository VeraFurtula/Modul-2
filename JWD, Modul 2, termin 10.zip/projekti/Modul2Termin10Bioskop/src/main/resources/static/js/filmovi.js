/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let tbody = document.querySelector("tbody");

	let buttonsSortNaziv = document.querySelectorAll("button.sort-naziv");
	let buttonsSortTrajanje = document.querySelectorAll("button.sort-trajanje");

	// funkcija za sortiranje tabele po prosleđenom komparatoru
	function sortTBody(comp) {
		// pravljenje niza od kolekcije HTML elemenata
		let redovi = Array.of(...tbody.children); // ... unpack operator
		redovi.sort(comp);

		// pražnjenje tabele
		while (tbody.children.length > 0) {
			tbody.children[0].remove();
		}
		// popunjavanje tabele u sortiranom redosledu redova
		for (let it in redovi) {
			let red = redovi[it];
			red.children[0].textContent = Number(it) + 1; // ažuriranje rednog broja
			tbody.append(red);
		}
	}

	// funkcije za sortiranje po koloni
	function sortNaziv(smer) {
		sortTBody(function(red1, red2) {
			let naziv1 = red1.children[1].children[0].textContent; // tr -> td -> a.textContent
			let naziv2 = red2.children[1].children[0].textContent;
			return smer*(naziv1.localeCompare(naziv2));
		});
	}
	function sortTrajanje(smer) {
		sortTBody(function(red1, red2) {
			let trajanje1 = Number(red1.children[3].textContent); // tr -> td.textContent
			let trajanje2 = Number(red2.children[3].textContent);
			return smer*(trajanje1 - trajanje2);
		});
	}

	// registracija događaja
	buttonsSortNaziv[0].onclick = function(event) { // event parametar je opisnik događaja
		sortNaziv(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortNaziv[1].onclick = function(event) { // event parametar je opisnik događaja
		sortNaziv(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortTrajanje[0].onclick = function(event) { // event parametar je opisnik događaja
		sortTrajanje(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortTrajanje[1].onclick = function(event) { // event parametar je opisnik događaja
		sortTrajanje(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
}
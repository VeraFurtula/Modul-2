/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let datumIVreme = document.querySelector("input[name=datumIVreme]");
	let filmId = document.querySelector("select[name=filmId]");
	let tip = document.querySelector("select[name=tip]");
	let sala = document.querySelector("input[name=sala]");
	let cenaKarte = document.querySelector("input[name=cenaKarte]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaDatumIVreme() {
		return new Date(datumIVreme.value) > new Date(); // input.value
	}
	function validacijaFilmId() {
		return filmId.value > 0; // input.value
	}
	function validacijaTip() {
		let vrednost = tip.value; // input.value
		return vrednost == "2D" || vrednost == "3D" || vrednost == "4D";
	}
	function validacijaSala() {
		let vrednost = Number(sala.value); // input.value
		return Number.isInteger(vrednost) && vrednost > 0 && vrednost <= 3;
	}
	function validacijaCenaKarte() {
		return Number(cenaKarte.value) > 0; // input.value
	}
	function validacija() {
		return validacijaDatumIVreme() && validacijaFilmId() && validacijaTip() && validacijaSala() && validacijaCenaKarte();
	}

	// registracija handler-a na događaje promene unosa input-a
	let datumIVremeCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaDatumIVreme()? "": "Datum i vreme ne smeju biti u prošlosti!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	datumIVreme.onchange = datumIVremeCallback;
	datumIVreme.onblur = datumIVremeCallback;
	datumIVreme.onkeyup = datumIVremeCallback;

	let filmIdCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaFilmId()? "": "Film mora biti odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	filmId.onchange = filmIdCallback;
	filmId.onblur = filmIdCallback;
	filmId.onkeyup = filmIdCallback;

	let tipCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaTip()? "": "Tip mora biti odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	tip.onchange = tipCallback;
	tip.onblur = tipCallback;
	tip.onkeyup = tipCallback;

	let salaCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaSala()? "": "Sala mora biti ceo broj između 1 i 3!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	sala.onchange = salaCallback;
	sala.onblur = salaCallback;
	sala.onkeyup = salaCallback;

	let cenaKarteCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaCenaKarte()? "": "Cena karte mora biti pozitivan broj!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	cenaKarte.onchange = cenaKarteCallback;
	cenaKarte.onblur = cenaKarteCallback;
	cenaKarte.onkeyup = cenaKarteCallback;

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


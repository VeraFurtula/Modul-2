/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let tbody = document.querySelector("tbody");

	let buttonsSortDatumIVreme = document.querySelectorAll("button.sort-datumIVreme");
	let buttonsSortFilm = document.querySelectorAll("button.sort-film");
	let buttonsSortTip = document.querySelectorAll("button.sort-tip");
	let buttonsSortSala = document.querySelectorAll("button.sort-sala");
	let buttonsSortCenaKarte = document.querySelectorAll("button.sort-cenaKarte");

	// funkcija za sortiranje tabele po prosleđenom komparatoru
	function sortTBody(comp) {
		// pravljenje niza od kolekcije HTML elemenata
		let redovi = Array.of(...tbody.children); // ... unpack operator
		redovi.sort(comp);

		// pražnjenje tabele
		while (tbody.children.length > 0) {
			tbody.children[0].remove();
		}
		// popunjavanje tabele u sortiranom redosledu redova
		for (let it in redovi) {
			let red = redovi[it];
			red.children[0].textContent = Number(it) + 1; // ažuriranje rednog broja
			tbody.append(red);
		}
	}

	function parseDate(string) {
		let tokens = string.split(" ");
		let date = tokens[0].split(".");
		let time = tokens[1].split(":");
		return new Date(`${date[2]}-${date[1]}-${date[0]}T${time[0]}:${time[1]}`);
	}

	// funkcije za sortiranje po koloni
	function sortDatumIVreme(smer) {
		sortTBody(function(red1, red2) {
			let datumIVreme1 = parseDate(red1.children[1].children[0].textContent); // tr -> td -> a.textContent
			let datumIVreme2 = parseDate(red2.children[1].children[0].textContent);
			if (datumIVreme1 > datumIVreme2) {
				return smer;
			} else if (datumIVreme2 > datumIVreme1) {
				return -smer;
			}
			return 0;
		});
	}
	function sortFilm(smer) {
		sortTBody(function(red1, red2) {
			let film1 = red1.children[2].children[0].textContent; // tr -> td -> a.textContent
			let film2 = red2.children[2].children[0].textContent;
			return smer*(film1.localeCompare(film2));
		});
	}
	function sortTip(smer) {
		sortTBody(function(red1, red2) {
			let tip1 = red1.children[3].textContent; // tr -> td.textContent
			let tip2 = red2.children[3].textContent;
			return smer*(tip1.localeCompare(tip2));
		});
	}
	function sortSala(smer) {
		sortTBody(function(red1, red2) {
			let sala1 = Number(red1.children[4].textContent); // tr -> td.textContent
			let sala2 = Number(red2.children[4].textContent);
			console.log(sala1)
			return smer*(sala1 - sala2);
		});
	}
	function sortCenaKarte(smer) {
		sortTBody(function(red1, red2) {
			let cenaKarte1 = Number(red1.children[5].textContent); // tr -> td.textContent
			let cenaKarte2 = Number(red2.children[5].textContent);
			return smer*(cenaKarte1 - cenaKarte2);
		});
	}

	// registracija događaja
	buttonsSortDatumIVreme[0].onclick = function(event) { // event parametar je opisnik događaja
		sortDatumIVreme(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortDatumIVreme[1].onclick = function(event) { // event parametar je opisnik događaja
		sortDatumIVreme(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortFilm[0].onclick = function(event) { // event parametar je opisnik događaja
		sortFilm(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortFilm[1].onclick = function(event) { // event parametar je opisnik događaja
		sortFilm(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortTip[0].onclick = function(event) { // event parametar je opisnik događaja
		sortTip(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortTip[1].onclick = function(event) { // event parametar je opisnik događaja
		sortTip(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortSala[0].onclick = function(event) { // event parametar je opisnik događaja
		sortSala(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortSala[1].onclick = function(event) { // event parametar je opisnik događaja
		sortSala(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortCenaKarte[0].onclick = function(event) { // event parametar je opisnik događaja
		sortCenaKarte(1); // rastući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
	buttonsSortCenaKarte[1].onclick = function(event) { // event parametar je opisnik događaja
		sortCenaKarte(-1); // opadajući redosled
		event.preventDefault(); // sprečavanje da dugme aktivira formu za pretragu i osveži stranicu
	}
}
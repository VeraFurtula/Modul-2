/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
	// keširanje referenci na elemente stranice
	let naziv = document.querySelector("input[name=naziv]");
	let zanrIds = document.querySelectorAll("input[name=zanrIds]");
	let trajanje = document.querySelector("input[name=trajanje]");

	let button = document.querySelectorAll("button")[0];

	// funkcije za validaciju
	function validacijaNaziv() {
		return naziv.value != ""; // input.value
	}
	function validacijaZanrIds() {
		let odabran = false;
		for (let itZanrId of zanrIds) {
			if (itZanrId.checked) { // input.checked (funkcioniše za checkbox i radio)
				odabran = true;
				break;
			}
		}
		return odabran;
	}
	function validacijaTrajanje() {
		let vrednost = Number(trajanje.value);
		return Number.isInteger(vrednost) && vrednost >= 5;
	}
	function validacija() {
		return validacijaNaziv() && validacijaZanrIds() && validacijaTrajanje();
	}

	// registracija handler-a na događaje promene unosa input-a
	let nazivCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaNaziv()? "": "Naziv ne sme biti prazan!";
	
		button.disabled = !validacija(); // objedinjena validacija
	};
	naziv.onchange = nazivCallback;
	naziv.onblur = nazivCallback;
	naziv.onkeyup = nazivCallback;

	let zanrIdsCallback = function(event) {
		// prikaz poruke
		let error = event.target.parentElement.parentElement.lastElementChild; // input -> div -> div -> small
		error.textContent = validacijaZanrIds()? "": "Bar jedan žanr mora biti odabran!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	for (let itZanrId of zanrIds) { // registracija handler-a na sve checkbox-e
		itZanrId.onchange = zanrIdsCallback;
		itZanrId.onblur = zanrIdsCallback;
		itZanrId.onkeyup = zanrIdsCallback;
	}

	let trajanjeCallback = function(event) {
		// prikaz poruke
		let error = event.target.nextElementSibling; // input -> small
		error.textContent = validacijaTrajanje()? "": "Trajanje mora biti ceo broj veći ili jednak 5!";

		// onesposobljavanje dugmeta
		button.disabled = !validacija(); // objedinjena validacija
	};
	trajanje.onchange = trajanjeCallback;
	trajanje.onblur = trajanjeCallback;
	trajanje.onkeyup = trajanjeCallback;

	/*
		Registracija handler-a na submit događaj forme.
		Nije neophodna, već služi kao dodatna kontrola jer teoretski ne može da se desi
		ako onesposobljavanje dugmeta funkcioniše.
	*/
	document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
		if (!validacija()) { // objedinjena validacija
			event.preventDefault(); // sprečavanje slanja zahteva iz forme
		}
	}

	// onesposobljavanje dugmeta forme po prikazu stranice
	button.disabled = !validacija();
}


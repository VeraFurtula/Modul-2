window.onload = function() {
	let korisnickoIme = document.querySelector("input[name=korisnickoIme]");
	let lozinka = document.querySelector("input[name=lozinka]");

	let button = document.querySelectorAll("button")[0];

	function validacijaKorisnickoIme() {
		return korisnickoIme.value != "";
	}
	function validacijaLozinka() {
		return lozinka.value != "";
	}
	function validacija() {
		return validacijaKorisnickoIme() && validacijaLozinka();
	}

	let korsicnikoImeCallback = function(event) {
		let error = event.target.nextElementSibling;
		error.textContent = validacijaKorisnickoIme()? "": "Korisničko ime ne sme biti prazno!";
	
		button.disabled = !validacija();
	};
	korisnickoIme.onchange = korsicnikoImeCallback;
	korisnickoIme.onblur = korsicnikoImeCallback;
	korisnickoIme.onkeyup = korsicnikoImeCallback;

	let lozinkaCallback = function(event) {
		let error = event.target.nextElementSibling;
		error.textContent = validacijaLozinka()? "": "Lozinka ne sme biti prazna!";
	
		button.disabled = !validacija();
	};
	lozinka.onchange = lozinkaCallback;
	lozinka.onblur = lozinkaCallback;
	lozinka.onkeyup = lozinkaCallback;

	document.querySelector("form").onsubmit = function(event) {
		if (!validacija()) {
			event.preventDefault();
		}
	}

	button.disabled = !validacija();
}


package com.ftninformatika.jwd.modul2.termin10.bioskop.dto;

public class NalogDTOGet extends NalogDTO {

	private boolean administrator;

	public boolean isAdministrator() {
		return administrator;
	}

	public void setAdministrator(boolean administrator) {
		this.administrator = administrator;
	}

}

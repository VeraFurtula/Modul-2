package com.ftninformatika.jwd.modul2.termin10.bioskop.dto;

public class ZanrDTOGet extends ZanrDTO {}

package com.ftninformatika.jwd.modul2.termin10.dostava.model.session;

import java.io.Serializable;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

@Component
@SessionScope
@SuppressWarnings("serial")
public class Prijava implements Serializable {

	private String korisnickoIme;

	public String getKorisnickoIme() {
		return korisnickoIme;
	}

	public void setKorisnickoIme(String korisnickoIme) {
		this.korisnickoIme = korisnickoIme;
	}

}

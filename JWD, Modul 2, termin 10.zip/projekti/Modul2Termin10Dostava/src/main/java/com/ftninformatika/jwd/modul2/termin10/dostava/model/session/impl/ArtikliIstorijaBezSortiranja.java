package com.ftninformatika.jwd.modul2.termin10.dostava.model.session.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import com.ftninformatika.jwd.modul2.termin10.dostava.model.session.ArtikliIstorija;

//@Primary
@Component
@SessionScope
@SuppressWarnings("serial")
public class ArtikliIstorijaBezSortiranja implements Serializable, ArtikliIstorija {

	private static final int KAPACITET = 5;

	private final List<Long> poseceniIDs = new ArrayList<>();

	@Override
	public void addPosecen(long id) {
		if (poseceniIDs.contains(id)) {
			return;
		}
		poseceniIDs.add(id);
	}

	@Override
	public void deletePosecen(long id) {
		Iterator<Long> it = poseceniIDs.iterator();
		while (it.hasNext()) {
			long itID = it.next();
			if (itID == id) {
				it.remove();
				break;
			}
		}
	}

	@Override
	public Collection<Long> getAllPoseceni() {
		if (poseceniIDs.size() > KAPACITET) {
			return poseceniIDs.subList(0, KAPACITET);
		}
		return Collections.unmodifiableCollection(poseceniIDs);
	}

}

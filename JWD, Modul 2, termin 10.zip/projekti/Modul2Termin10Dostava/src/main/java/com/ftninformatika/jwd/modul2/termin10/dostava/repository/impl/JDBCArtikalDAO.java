package com.ftninformatika.jwd.modul2.termin10.dostava.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ftninformatika.jwd.modul2.termin10.dostava.model.Artikal;
import com.ftninformatika.jwd.modul2.termin10.dostava.model.Restoran;
import com.ftninformatika.jwd.modul2.termin10.dostava.repository.ArtikalDAO;
import com.ftninformatika.jwd.modul2.termin10.dostava.repository.RestoranDAO;

//@Primary
@Repository
public class JDBCArtikalDAO implements ArtikalDAO {

	private final JdbcTemplate jdbcTemplate;
	private final RestoranDAO restoranDAO;

	public JDBCArtikalDAO(JdbcTemplate jdbcTemplate, RestoranDAO filmDAO) {
		this.jdbcTemplate = jdbcTemplate;
		this.restoranDAO = filmDAO;
	}

	private class ArtikalRowMapper implements RowMapper<Artikal> {

		@Override
		public Artikal mapRow(ResultSet rset, int rowNum) throws SQLException {
			int kolona = 0;
			long id = rset.getLong(++kolona);
			String naziv = rset.getString(++kolona);
			String opis = rset.getString(++kolona);
			double cena = rset.getDouble(++kolona);
			long restoranId = rset.getLong(++kolona);
			
			Artikal artikal = new Artikal(id, naziv, opis, cena);
			
			Restoran restoran = restoranDAO.get(restoranId);
			if (restoran != null) {
				artikal.setRestoran(restoran);
			}
			return artikal;
		}

	}

	@Override
	public Artikal get(long id) {
		String sql = "SELECT id, naziv, opis, cena, restoranId FROM artikli WHERE id = ?";

		List<Artikal> rezultat = jdbcTemplate.query(sql, new ArtikalRowMapper(), id);
		return (!rezultat.isEmpty())? rezultat.get(0): null;
	}

	@Override
	public Collection<Artikal> getAll() {
		String sql = "SELECT id, naziv, opis, cena, restoranId FROM artikli";
		return jdbcTemplate.query(sql, new ArtikalRowMapper());
	}

	@Override
	public Collection<Artikal> get(String naziv, String opis, double cenaOd, double cenaDo, long restoranId) {
		String sql = 
				"SELECT id, naziv, opis, cena, restoranId FROM artikli" + 
				"WHERE (? IS NULL OR naziv LIKE ?) " + 
				"AND (? IS NULL OR opis LIKE ?) " + 
				"AND (? <= 0 OR cena >= ?) " + 
				"AND (? <= 0 OR cena <= ?) " + 
				"AND (? <= 0 OR restoranId = ?)";
		return jdbcTemplate.query(sql, new ArtikalRowMapper(), 
				naziv, "%" + naziv + "%", 
				opis, "%" + opis + "%", 
				cenaOd, cenaOd, 
				cenaDo, cenaDo,  
				restoranId, restoranId);
	}

	@Override
	public void add(Artikal artikal) {
		String sql = "INSERT INTO artikli (naziv, opis, cena, restoranId) VALUES (?, ?, ?, ?)";
		jdbcTemplate.update(sql, 
				artikal.getNaziv(), 
				artikal.getOpis(), 
				artikal.getCena(), 
				artikal.getRestoran().getId());
	}

	@Override
	public void update(Artikal artikal) {
		String sql = "UPDATE artikli SET naziv = ?, opis = ?, cena = ?, restoranId = ? WHERE id = ?";
		jdbcTemplate.update(sql, 
				artikal.getNaziv(), 
				artikal.getOpis(), 
				artikal.getCena(), 
				artikal.getRestoran().getId(), 
				artikal.getId());
	}

	@Override
	public void delete(long id) {
		String sql = "DELETE FROM artikli WHERE id = ?";
		jdbcTemplate.update(sql, id);
	}

}

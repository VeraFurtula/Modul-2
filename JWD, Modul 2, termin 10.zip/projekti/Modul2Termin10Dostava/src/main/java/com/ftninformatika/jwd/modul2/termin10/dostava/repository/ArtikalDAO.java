package com.ftninformatika.jwd.modul2.termin10.dostava.repository;

import java.util.Collection;

import com.ftninformatika.jwd.modul2.termin10.dostava.model.Artikal;

public interface ArtikalDAO {

	public Artikal get(long id);
	public Collection<Artikal> getAll();
	public Collection<Artikal> get(
			String naziv, 
			String opis, 
			double cenaOd, double cenaDo, 
			long restoranId);
	public void add(Artikal artikal);
	public void update(Artikal artikal);
	public void delete(long id);

}

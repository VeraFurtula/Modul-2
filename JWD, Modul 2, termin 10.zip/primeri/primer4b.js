/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
    let lista = document.querySelector("ol");
    lista.insertAdjacentHTML("afterbegin", "<li>Prvi</li>");
    lista.insertAdjacentHTML("beforeend", "<li>Treći</li>");

    let stavka = document.querySelector("ul li");
    stavka.insertAdjacentHTML("beforebegin", "<li>Pre</li>");
    stavka.insertAdjacentHTML("afterend", "<li>Posle</li>");

    // registracija handler-a
    document.querySelector("button:first-of-type").onclick = function() {
        while (lista.children.length > 0) { // uvek while petljom uklanjati niz čvorova!
            lista.children[0].remove();
        }
    };
    document.querySelector("button:last-of-type").onclick = function() {
        stavka.remove();
    };
}

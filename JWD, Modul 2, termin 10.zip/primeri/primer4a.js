/*
	Ako se pronalaženje elemenata i registracija handler-a
	obavlja unutar window.onload handler-a (koji se izvršava po učitavanju stranice), 
	defer atribut na script elementu nije potreban.
*/
window.onload = function() {
    let prvi = document.createElement("li");
    prvi.textContent = "Prvi";
    let treci = document.createElement("li");
    treci.textContent = "Treći";

    let lista = document.querySelector("ol");
    lista.prepend(prvi);
    lista.append(treci);

    let pre = document.createElement("li");
    pre.textContent = "Pre";
    let posle = document.createElement("li");
    posle.textContent = "Posle";

    let stavka = document.querySelector("ul li");
    stavka.before(pre);
    stavka.after(posle);

    // registracija handler-a
    document.querySelector("button:first-of-type").onclick = function() {
        while (lista.children.length > 0) { // uvek while petljom uklanjati niz čvorova!
            lista.children[0].remove();
        }
    };
    document.querySelector("button:last-of-type").onclick = function() {
        stavka.remove();
    };
}

// registracija handler-a
window.onload = function() {
    alert("onload");
};

document.onkeyup = function(event) { // event parametar je opisnik događaja
    console.log(event);
    alert("onkeyup");
};

document.querySelector("p:nth-child(2)").onmouseover = function(event) { // event parametar je opisnik događaja
    console.log(event);
    alert("onmouseover");
};

document.querySelector("button").onclick = function(event) { // event parametar je opisnik događaja
    console.log(event);
    alert("onclick");
};

document.querySelector("form").onsubmit = function(event) { // event parametar je opisnik događaja
    console.log(event);
    alert("onsubmit");
    //event.preventDefault(); // sprečavanje slanja zahteva iz forme
};

document.querySelector("input[type=text]").onfocus = function(event) { // event parametar je opisnik događaja
    console.log(event);
    alert("onfocus");
};
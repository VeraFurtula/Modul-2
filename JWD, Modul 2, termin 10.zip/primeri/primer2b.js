document.querySelector("#pasus_id").textContent = "Pasus"; // pronalaženje po id
document.querySelector(".pasus_klasa").textContent = "Pasus"; // pronalaženje po nazivu klase

let linkovi = document.querySelectorAll("a"); // pronalaženje po nazivu elementa
for (let itLink of linkovi) {
    itLink.textContent = "Link";
}

let stavke = document.querySelectorAll("ul li"); // pronalaženje po nazivu elementa sa zajedničkim roditeljem
for (let itStavka of stavke) {
    itStavka.textContent = "Neuređena lista";
}

document.querySelector("ol li:first-child").textContent = "Prvi"; // pronalaženje po nazivu elementa sa zajedničkim roditeljem i dodatnim uslovom
document.querySelector("ol li:nth-child(2)").textContent = "Drugi"; // pronalaženje po nazivu elementa sa zajedničkim roditeljem i dodatnim uslovom
document.querySelector("ol li:last-child").textContent = "Treći"; // pronalaženje po nazivu elementa sa zajedničkim roditeljem i dodatnim uslovom

document.querySelector("input[type=text]").value = "Polje za unos"; // pronalaženje po vrednosti atributa
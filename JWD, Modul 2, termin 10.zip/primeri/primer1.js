function prikazi(element, razmak = "") {
    if (razmak == "") {
        console.log(element);
    } else {
        console.log(razmak, element);
    }
    for (let itElement of element.children) {
        prikazi(itElement, razmak + "    ") // rekurzija
    }
};

prikazi(document);

let html = document.children[0];
console.log("html:", html);

let head = html.children[0];
console.log("head:", head);

let body = html.children[1];
console.log("body:", body);

let title = head.children[0];
console.log("title:", title);

let script = head.children[1];
console.log("script:", script);

let a = body.children[0];
console.log("a:", a);

let form = body.children[1];
console.log("form:", form);

let input = form.children[0];
console.log("input:", input);

let button = form.children[1];
console.log("button:", button);
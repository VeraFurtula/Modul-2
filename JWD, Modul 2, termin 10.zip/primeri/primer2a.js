document.getElementById("pasus_id").textContent = "Pasus"; // pronalaženje po id
document.getElementsByClassName("pasus_klasa")[0].textContent = "Pasus"; // pronalaženje po nazivu klase

let linkovi = document.getElementsByTagName("a"); // pronalaženje po nazivu elementa
for (let itLink of linkovi) {
    itLink.textContent = "Link";
}

let stavke = document.getElementsByTagName("ul")[0].children; // pronalaženje po nazivu elementa
for (let itStavka of stavke) {
    itStavka.textContent = "Neuređena lista";
}

document.getElementsByTagName("ol")[0].children[0].textContent = "Prvi";  // pronalaženje po nazivu elementa
document.getElementsByTagName("ol")[0].children[1].textContent = "Drugi";  // pronalaženje po nazivu elementa
document.getElementsByTagName("ol")[0].children[2].textContent = "Treći";  // pronalaženje po nazivu elementa

document.getElementsByName("korisnickoIme")[0].value = "Polje za unos"; // pronalaženje po name atributu elementa